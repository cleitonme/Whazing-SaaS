<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sms_whatsapi extends App_sms
{
    public function __construct()
    {
        parent::__construct();

        $this->add_gateway('whatsapi', [
            'name'    => 'WhatsApp API Whazing',
            'info'    => '<p>OS contatos devem estar no formato internacional sem o <b>+</b> - Formato: *55* DD *NNNN-NNNN*',
            'options' => [
                [
                    'name'  => 'endpoint',
                    'label' => 'URL da API',
                ],
                [
                    'name'  => 'bearer_token',
                    'label' => 'Token',
                ],
            ],
        ]);
    }

    /**
     * Format phone number to API required format
     * 
     * @param string $number Phone number to format
     * @return string Formatted phone number (only digits)
     */
    private function format_phone_number($number)
    {
        // Remove any type of brackets, spaces, plus signs and special characters
        $number = preg_replace('/[\(\)\[\]\{\}\-\.\+\s]/', '', $number);
        
        // Remove any non-numeric characters that might remain
        $number = preg_replace('/[^0-9]/', '', $number);
        
        // If the number starts with 0, remove it
        $number = ltrim($number, '0');
        
        // If number doesn't start with country code 55 and has correct length for BR number
        if (!preg_match('/^55/', $number) && (strlen($number) == 10 || strlen($number) == 11)) {
            $number = '55' . $number;
        }
        
        return $number;
    }

    public function send($number, $message)
    {
        $endpoint     = $this->get_option('whatsapi', 'endpoint');
        $bearer_token = $this->get_option('whatsapi', 'bearer_token');
        
        // Use the new formatting function
        $formatted_number = $this->format_phone_number($number);
        
        $send = $this->send_to_api($endpoint, $bearer_token, $formatted_number, $message);

        if ($send['success']) {
            log_activity('Notificação enviada via Whatsapp para: ' . $formatted_number . ', mensagem: ' . $message);
            return true;
        } else {
            log_activity($this->set_error('O envio falhou : <BR> Erro: ' . $send['message']));
            return false;
        }
    }

    public function send_to_api($endpoint, $bearer_token, $number, $text)
    {
        $apiData = [
            "number" => $number,
            "body" => $text,
            "externalKey" => "PerfexCRM"
        ];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($apiData),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Bearer ' . $bearer_token,
            )
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
        if ($err) {
            return ['success' => false, 'message' => $err];
        } else {
            return ['success' => true, 'message' => $response];
        }
    }
}