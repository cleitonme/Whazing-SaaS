<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Atendimentoiframe extends AdminController
{
    public function index()
    {
        $data['title'] = _l('atendimentoiframe_menu');
        $data['url']   = get_option('atendimentoiframe_url');
		$data['sidebar_collapse'] = true;
        $this->load->view('iframe_view', $data);
    }

    public function settings()
    {
        if ($this->input->post()) {
            $url = $this->input->post('iframe_url');
            update_option('atendimentoiframe_url', $url);
            set_alert('success', 'URL atualizada com sucesso');
            redirect(admin_url('atendimentoiframe/settings'));
        }

        $data['title'] = 'Configuração Atendimento';
        $data['url']   = get_option('atendimentoiframe_url');
        $this->load->view('settings_view', $data);
    }
}
