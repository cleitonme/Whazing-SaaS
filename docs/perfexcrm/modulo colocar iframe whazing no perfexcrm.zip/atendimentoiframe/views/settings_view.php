<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div class="wrapper">
   <div class="content">
      <div class="panel_s">
         <div class="panel-heading">Configuração do Iframe</div>
         <div class="panel-body">
            <form method="post">
               <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" 
                      value="<?php echo $this->security->get_csrf_hash(); ?>" />
               <div class="form-group">
                  <label for="iframe_url">URL do Atendimento</label>
                  <input type="text" name="iframe_url" id="iframe_url" class="form-control" value="<?php echo html_escape($url); ?>" required>
               </div>
               <button type="submit" class="btn btn-primary">Salvar</button>
            </form>
         </div>
      </div>
   </div>
</div>
<?php init_tail(); ?>
