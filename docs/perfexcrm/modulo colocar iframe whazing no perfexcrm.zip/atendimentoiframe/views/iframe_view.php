<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
  /* Container para ocupar espaço do conteúdo */
  .content iframe {
    width: 100%;
    height: calc(100vh - 120px); /* altura total da viewport menos cabeçalho */
    border: none;
  }
</style>
<div class="content">
  <iframe src="<?php echo html_escape($url); ?>"></iframe>
</div>
<?php init_tail(); ?>
