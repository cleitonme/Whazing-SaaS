<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: IFrame Whazing.
Description: Exibe um iframe de atendimento no menu lateral.
Author: Whazing.
Author URI: https://www.whazing.com.br
Version: 1.0.0
Requires at least: 3.0.*
*/

register_language_files('atendimentoiframe', ['atendimentoiframe']);

// Adiciona item ao menu lateral
hooks()->add_action('admin_init', function () {
    if (is_admin()) {
        $CI = &get_instance();
        $CI->app_menu->add_sidebar_menu_item('atendimentoiframe', [
            'name'     => _l('atendimentoiframe_menu'),
            'href'     => admin_url('atendimentoiframe'),
            'icon'     => 'fa fa-comments',
            'position' => 60
        ]);
    }

    add_option('atendimentoiframe_url', '', 1);
});
