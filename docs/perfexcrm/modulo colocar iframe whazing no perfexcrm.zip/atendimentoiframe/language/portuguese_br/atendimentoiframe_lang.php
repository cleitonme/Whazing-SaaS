<?php
$lang['atendimentoiframe_menu'] = 'Atendimento';
